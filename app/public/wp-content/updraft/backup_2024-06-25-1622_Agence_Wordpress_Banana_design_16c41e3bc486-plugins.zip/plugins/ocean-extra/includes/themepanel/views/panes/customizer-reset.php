<h3 class="oceanwp-tp-block-description">
    <?php esc_html_e( 'Delete your settings and reset all Customizer options to default theme values.', 'ocean-extra' ); ?>
</h3>
<div id="ocean-customizer-reset" class="column-wrap clr">
	<button class="btn button"><?php esc_html_e( 'Reset Customizer Settings', 'ocean-extra' ); ?></button>
</div>
